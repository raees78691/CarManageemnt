import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-car',
  templateUrl: './car.component.html',
})
export class CarComponent {
  car: any = {
    carNumber: '',
    carCategory: '',
    rateHour: 0,
    bookingDetail: {
      pickupPoint: '',
      dropPoint: '',
      pickupDate: '',
      pickupTime: '',
      dropDate: '',
      dropTime: '',
      driver: [{
        name: '',
        mobNumber: '',
        licenceNo: ''
      }]
    }
  };

  carDetails: any;

  constructor(private http: HttpClient) {}

  bookCar() {
    this.http.post('/cars/book', this.car).subscribe(res => {
      alert('Car Booked Successfully');
    });
  }

  getBookingDetails(carNumber: string) {
    this.http.get(`/cars/${carNumber}`).subscribe(res => {
      this.carDetails = res;
    });
  }
}